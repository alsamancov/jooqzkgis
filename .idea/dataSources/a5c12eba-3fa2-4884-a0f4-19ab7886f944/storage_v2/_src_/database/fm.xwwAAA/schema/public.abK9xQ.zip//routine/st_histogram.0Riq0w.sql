CREATE FUNCTION st_histogram(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, bins integer DEFAULT 0, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision)
  RETURNS SETOF record
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, $3, 1, $4, $5, $6)
$$;

