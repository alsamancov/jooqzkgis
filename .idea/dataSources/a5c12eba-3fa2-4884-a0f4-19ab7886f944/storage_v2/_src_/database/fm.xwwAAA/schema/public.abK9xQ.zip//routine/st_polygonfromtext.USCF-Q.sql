CREATE FUNCTION st_polygonfromtext(text, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_PolyFromText($1, $2)
$$;

