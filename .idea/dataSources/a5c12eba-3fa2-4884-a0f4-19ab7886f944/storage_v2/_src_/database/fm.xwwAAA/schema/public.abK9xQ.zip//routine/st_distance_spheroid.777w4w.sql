CREATE FUNCTION st_distance_spheroid(geom1 geometry, geom2 geometry, spheroid)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Distance_Spheroid', 'ST_DistanceSpheroid', '2.2.0');
    SELECT public.ST_DistanceSpheroid($1,$2,$3);
$$;

