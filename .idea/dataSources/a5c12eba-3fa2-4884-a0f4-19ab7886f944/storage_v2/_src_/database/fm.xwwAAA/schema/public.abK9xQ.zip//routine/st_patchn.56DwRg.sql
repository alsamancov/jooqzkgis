CREATE FUNCTION st_patchn(geometry, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_GeometryN($1, $2)
	ELSE NULL END

$$;

