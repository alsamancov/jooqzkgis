CREATE FUNCTION st_asjpeg(rast raster, nband integer, options text[] DEFAULT NULL::text[])
  RETURNS bytea
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.st_asjpeg(st_band($1, $2), $3)
$$;

