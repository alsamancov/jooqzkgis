CREATE FUNCTION st_summarystats(rast raster, exclude_nodata_value boolean)
  RETURNS summarystats
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, 1, $2, 1)
$$;

