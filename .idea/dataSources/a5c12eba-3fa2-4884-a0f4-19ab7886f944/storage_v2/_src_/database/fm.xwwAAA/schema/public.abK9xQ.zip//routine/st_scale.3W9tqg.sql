CREATE FUNCTION st_scale(geometry, double precision, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Scale($1, $2, $3, 1)
$$;

