CREATE FUNCTION get_proj4_from_srid(integer)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE plpgsql
AS $$
BEGIN
	RETURN proj4text::text FROM public.spatial_ref_sys WHERE srid= $1;
END;
$$;

