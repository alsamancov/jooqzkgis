CREATE FUNCTION postgis_scripts_installed()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.4.3'::text AS version
$$;

