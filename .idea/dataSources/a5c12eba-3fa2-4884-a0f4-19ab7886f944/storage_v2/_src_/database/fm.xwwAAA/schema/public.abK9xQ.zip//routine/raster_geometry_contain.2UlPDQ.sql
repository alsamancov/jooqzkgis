CREATE FUNCTION raster_geometry_contain(raster, geometry)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry ~ $2
$$;

