CREATE FUNCTION st_setvalue(rast raster, nband integer, geom geometry, newvalue double precision)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_setvalues($1, $2, ARRAY[ROW($3, $4)]::geomval[], FALSE)
$$;

