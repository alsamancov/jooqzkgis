CREATE FUNCTION st_rotatez(geometry, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Rotate($1, $2)
$$;

