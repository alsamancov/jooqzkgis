CREATE FUNCTION st_combine_bbox(box2d, geometry)
  RETURNS box2d
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Combine_BBox', 'ST_CombineBbox', '2.2.0');
    SELECT public.ST_CombineBbox($1,$2);
$$;

