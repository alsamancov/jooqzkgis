CREATE FUNCTION st_maxdistance(geom1 geometry, geom2 geometry)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_MaxDistance(public.ST_ConvexHull($1), public.ST_ConvexHull($2))
$$;

